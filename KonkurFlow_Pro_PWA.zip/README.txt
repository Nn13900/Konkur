KonkurFlow Pro
فایل‌ها را کنار هم نگه دار.
برای نصب PWA روی Home Screen، پروژه را روی HTTPS (مثل GitHub Pages یا Netlify) قرار بده.
Android/Chrome: منو > Install app / Add to Home screen
iPhone/Safari: Share > Add to Home Screen
